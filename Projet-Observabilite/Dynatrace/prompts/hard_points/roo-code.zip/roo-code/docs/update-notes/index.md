# Update Notes

This section contains notes about recent updates to Roo Code, listed by version number.

## Version 3.18

*   [3.18](/update-notes/v3.18) (2025-05-21)

## Version 3.17

*   [3.17.2](/update-notes/v3.17.2) (2025-05-15)
*   [3.17.1](/update-notes/v3.17.1) (2025-05-15)
*   [3.17.0](/update-notes/v3.17.0) (2025-05-14)
*   [3.17](/update-notes/v3.17) (2025-05-14)

## Version 3.16

*   [3.16.6](/update-notes/v3.16.6) (2025-05-12)
*   [3.16.5](/update-notes/v3.16.5) (2025-05-10)
*   [3.16.4](/update-notes/v3.16.4) (2025-05-09)
*   [3.16.3](/update-notes/v3.16.3) (2025-05-08)
*   [3.16.2](/update-notes/v3.16.2) (2025-05-07)
*   [3.16.1](/update-notes/v3.16.1) (2025-05-07)
*   [3.16](/update-notes/v3.16) (2025-05-12)

## Version 3.15

*   [3.15](/update-notes/v3.15) (2025-05-05)
*   [3.15.5](/update-notes/v3.15.5) (2025-05-05)
*   [3.15.4](/update-notes/v3.15.4) (2025-05-04)
*   [3.15.3](/update-notes/v3.15.3) (2025-05-02)
*   [3.15.2](/update-notes/v3.15.2) (2025-05-02)
*   [3.15.1](/update-notes/v3.15.1) (2025-04-30)
*   [3.15.0](/update-notes/v3.15.0) (2025-04-30)

## Version 3.14

*   [3.14](/update-notes/v3.14) (2025-04-24)
*   [3.14.3](/update-notes/v3.14.3) (2025-04-25)
*   [3.14.2](/update-notes/v3.14.2) (2025-04-24)
*   [3.14.1](/update-notes/v3.14.1) (2025-04-24)
*   [3.14.0](/update-notes/v3.14.0) (2025-04-23)

## Version 3.13

*   [3.13](/update-notes/v3.13) (2025-04-18)
*   [3.13.2](/update-notes/v3.13.2) (2025-04-18)
*   [3.13.1](/update-notes/v3.13.1) (2025-04-18)
*   [3.13.0](/update-notes/v3.13.0) (2025-04-17)

## Version 3.12

*   [3.12](/update-notes/v3.12) (2025-04-17)
*   [3.12.3](/update-notes/v3.12.3) (2025-04-17)
*   [3.12.2](/update-notes/v3.12.2) (2025-04-16)
*   [3.12.1](/update-notes/v3.12.1) (2025-04-16)
*   [3.12.0](/update-notes/v3.12.0) (2025-04-15)

## Version 3.11

*   [3.11.17](/update-notes/v3.11.17) (2025-04-14)
*   [3.11.16](/update-notes/v3.11.16) (2025-04-14)
*   [3.11.15](/update-notes/v3.11.15) (2025-04-13)
*   [3.11.14](/update-notes/v3.11.14) (2025-04-11)
*   [3.11.13](/update-notes/v3.11.13) (2025-04-11)
*   [3.11.12](/update-notes/v3.11.12) (2025-04-09)
*   [3.11.11](/update-notes/v3.11.11) (2025-04-09)
*   [3.11.10](/update-notes/v3.11.10) (2025-04-08)
*   [3.11.9](/update-notes/v3.11.9) (2025-04-07)
*   [3.11.8](/update-notes/v3.11.8) (2025-04-05)
*   [3.11.7](/update-notes/v3.11.7) (2025-04-04)
*   [3.11.6](/update-notes/v3.11.6) (2025-04-04)
*   [3.11.5](/update-notes/v3.11.5) (2025-04-03)
*   [3.11.4](/update-notes/v3.11.4) (2025-04-02)
*   [3.11.3](/update-notes/v3.11.3) (2025-03-31)
*   [3.11.2](/update-notes/v3.11.2) (2025-03-31)
*   [3.11.1](/update-notes/v3.11.1) (2025-03-30)
*   [3.11](/update-notes/v3.11) (2025-03-30)
*   [3.11.0](/update-notes/v3.11.0) (2025-03-30)

## Version 3.10

*   [3.10](/update-notes/v3.10) (2025-03-25)
*   [3.10.5](/update-notes/v3.10.5) (2025-03-25)
*   [3.10.4](/update-notes/v3.10.4) (2025-03-25)
*   [3.10.3](/update-notes/v3.10.3) (2025-03-23)
*   [3.10.2](/update-notes/v3.10.2) (2025-03-21)
*   [3.10.1](/update-notes/v3.10.1) (2025-03-20)
*   [3.10.0](/update-notes/v3.10.0) (2025-03-20)

## Version 3.9

*   [3.9](/update-notes/v3.9) (2025-03-19)
*   [3.9.2](/update-notes/v3.9.2) (2025-03-19)
*   [3.9.1](/update-notes/v3.9.1) (2025-03-18)
*   [3.9.0](/update-notes/v3.9.0) (2025-03-18)

## Version 3.8

*   [3.8](/update-notes/v3.8) (2025-03-13)
*   [3.8.6](/update-notes/v3.8.6) (2025-03-13)
*   [3.8.5](/update-notes/v3.8.5) (2025-03-12)
*   [3.8.4](/update-notes/v3.8.4) (2025-03-09)
*   [3.8.3](/update-notes/v3.8.3) (2025-03-09)
*   [3.8.2](/update-notes/v3.8.2) (2025-03-08)
*   [3.8.1](/update-notes/v3.8.1) (2025-03-07)
*   [3.8.0](/update-notes/v3.8.0) (2025-03-07)

## Version 3.7

*   [3.7](/update-notes/v3.7) (2025-03-03)
*   [3.7.12](/update-notes/v3.7.12) (2025-03-03)
*   [3.7.11](/update-notes/v3.7.11) (2025-03-02)
*   [3.7.10](/update-notes/v3.7.10) (2025-03-01)
*   [3.7.9](/update-notes/v3.7.9) (2025-03-01)
*   [3.7.8](/update-notes/v3.7.8) (2025-02-27)
*   [3.7.7](/update-notes/v3.7.7) (2025-02-27)
*   [3.7.6](/update-notes/v3.7.6) (2025-02-26)
*   [3.7.5](/update-notes/v3.7.5) (2025-02-26)
*   [3.7.4](/update-notes/v3.7.4) (2025-02-25)
*   [3.7.3](/update-notes/v3.7.3) (2025-02-25)
*   [3.7.2](/update-notes/v3.7.2) (2025-02-24)
*   [3.7.1](/update-notes/v3.7.1) (2025-02-24)
*   [3.7.0](/update-notes/v3.7.0) (2025-02-24)

## Version 3.3

*   [3.3](/update-notes/v3.3) (2025-02-27)
*   [3.3.26](/update-notes/v3.3.26) (2025-02-27)
*   [3.3.25](/update-notes/v3.3.25) (2025-02-21)
*   [3.3.24](/update-notes/v3.3.24) (2025-02-20)
*   [3.3.23](/update-notes/v3.3.23) (2025-02-20)
*   [3.3.22](/update-notes/v3.3.22) (2025-02-20)
*   [3.3.21](/update-notes/v3.3.21) (2025-02-17)
*   [3.3.20](/update-notes/v3.3.20) (2025-02-14)
*   [3.3.19](/update-notes/v3.3.19) (2025-02-12)
*   [3.3.18](/update-notes/v3.3.18) (2025-02-11)
*   [3.3.17](/update-notes/v3.3.17) (2025-02-09)
*   [3.3.16](/update-notes/v3.3.16) (2025-02-09)
*   [3.3.15](/update-notes/v3.3.15) (2025-02-08)
*   [3.3.14](/update-notes/v3.3.14)
*   [3.3.13](/update-notes/v3.3.13)
*   [3.3.12](/update-notes/v3.3.12)
*   [3.3.11](/update-notes/v3.3.11)
*   [3.3.10](/update-notes/v3.3.10)
*   [3.3.9](/update-notes/v3.3.9)
*   [3.3.8](/update-notes/v3.3.8)
*   [3.3.7](/update-notes/v3.3.7)
*   [3.3.6](/update-notes/v3.3.6)
*   [3.3.5](/update-notes/v3.3.5)
*   [3.3.4](/update-notes/v3.3.4)
*   [3.3.3](/update-notes/v3.3.3)
*   [3.3.2](/update-notes/v3.3.2)
*   [3.3.1](/update-notes/v3.3.1)
*   [3.3.0](/update-notes/v3.3.0)

## Version 3.2

*   [3.2](/update-notes/v3.2) (2025-02-27)
*   [3.2.8](/update-notes/v3.2.8)
*   [3.2.7](/update-notes/v3.2.7)
*   [3.2.6](/update-notes/v3.2.6)
*   [3.2.5](/update-notes/v3.2.5)
*   [3.2.4](/update-notes/v3.2.4)
*   [3.2.3](/update-notes/v3.2.3)
*   [3.2.0](/update-notes/v3.2.0) (Includes 3.2.1, 3.2.2)

## Version 3.1

*   [3.1](/update-notes/v3.1) (2025-02-27)
*   [3.1.7](/update-notes/v3.1.7)
*   [3.1.6](/update-notes/v3.1.6)
*   [3.1.4](/update-notes/v3.1.4) (Includes 3.1.5 fix)
*   [3.1.3](/update-notes/v3.1.3)
*   [3.1.2](/update-notes/v3.1.2)
*   [3.1.1](/update-notes/v3.1.1)
*   [3.1.0](/update-notes/v3.1.0)

## Version 3.0

*   [3.0](/update-notes/v3.0) (2025-02-27)
*   [3.0.3](/update-notes/v3.0.3)
*   [3.0.2](/update-notes/v3.0.2)
*   [3.0.1](/update-notes/v3.0.1)
*   [3.0.0](/update-notes/v3.0.0)

## Version 2.2

*   [2.2](/update-notes/v2.2) (2025-02-27)
*   [2.2.46](/update-notes/v2.2.46)
*   [2.2.45](/update-notes/v2.2.45)
*   [2.2.44](/update-notes/v2.2.44)
*   [2.2.43](/update-notes/v2.2.43)
*   [2.2.42](/update-notes/v2.2.42)
*   [2.2.41](/update-notes/v2.2.41)
*   [2.2.40](/update-notes/v2.2.40)
*   [2.2.39](/update-notes/v2.2.39)
*   [2.2.38](/update-notes/v2.2.38)
*   [2.2.36](/update-notes/v2.2.36) (Includes 2.2.37)
*   [2.2.35](/update-notes/v2.2.35)
*   [2.2.34](/update-notes/v2.2.34)
*   [2.2.33](/update-notes/v2.2.33)
*   [2.2.32](/update-notes/v2.2.32)
*   [2.2.31](/update-notes/v2.2.31)
*   [2.2.30](/update-notes/v2.2.30)
*   [2.2.29](/update-notes/v2.2.29)
*   [2.2.28](/update-notes/v2.2.28)
*   [2.2.27](/update-notes/v2.2.27)
*   [2.2.26](/update-notes/v2.2.26)
*   [2.2.25](/update-notes/v2.2.25)
*   [2.2.24](/update-notes/v2.2.24)
*   [2.2.23](/update-notes/v2.2.23)
*   [2.2.22](/update-notes/v2.2.22)
*   [2.2.21](/update-notes/v2.2.21)
*   [2.2.20](/update-notes/v2.2.20)
*   [2.2.19](/update-notes/v2.2.19)
*   [2.2.18](/update-notes/v2.2.18)
*   [2.2.17](/update-notes/v2.2.17)
*   [2.2.16](/update-notes/v2.2.16)
*   [2.2.14](/update-notes/v2.2.14) (Includes 2.2.15)
*   [2.2.13](/update-notes/v2.2.13)
*   [2.2.12](/update-notes/v2.2.12)
*   [2.2.11](/update-notes/v2.2.11)
*   [2.2.6](/update-notes/v2.2.6) (Includes 2.2.7-2.2.10)
*   [2.2.5](/update-notes/v2.2.5)
*   [2.2.4](/update-notes/v2.2.4)
*   [2.2.3](/update-notes/v2.2.3)
*   [2.2.2](/update-notes/v2.2.2)
*   [2.2.1](/update-notes/v2.2.1)
*   [2.2.0](/update-notes/v2.2.0)

## Version 2.1

*   [2.1](/update-notes/v2.1) (2025-02-27)
*   [2.1.21](/update-notes/v2.1.21)
*   [2.1.20](/update-notes/v2.1.20)
*   [2.1.19](/update-notes/v2.1.19)
*   [2.1.18](/update-notes/v2.1.18)
*   [2.1.17](/update-notes/v2.1.17)
*   [2.1.16](/update-notes/v2.1.16)
*   [2.1.15](/update-notes/v2.1.15)
*   [2.1.14](/update-notes/v2.1.14)
*   [2.1.13](/update-notes/v2.1.13)
*   [2.1.12](/update-notes/v2.1.12)
*   [2.1.11](/update-notes/v2.1.11)
*   [2.1.10](/update-notes/v2.1.10)
*   [2.1.9](/update-notes/v2.1.9)
*   [2.1.8](/update-notes/v2.1.8)
*   [2.1.7](/update-notes/v2.1.7)
*   [2.1.6](/update-notes/v2.1.6)
*   [2.1.5](/update-notes/v2.1.5)
*   [2.1.4](/update-notes/v2.1.4)
*   [2.1.3](/update-notes/v2.1.3)
*   [2.1.2](/update-notes/v2.1.2)